from sqlalchemy import create_engine
import pandas as pd
import numpy as np
 
# Postgres database connection
DATABASE_USER = 'postgres'
DATABASE_PASSWORD = 'Mogal@5807'
DATABASE_HOST = 'localhost'
DATABASE_PORT = '5432'
DATABASE_NAME = 'postgres'
 
# Establishing connection to the database
engine = create_engine(f'postgresql://{DATABASE_USER}:{DATABASE_PASSWORD}@{DATABASE_HOST}:{DATABASE_PORT}/{DATABASE_NAME}')
 
 
# Create framework that holds data
patients_df = pd.read_sql_query('SELECT * FROM customers', engine)
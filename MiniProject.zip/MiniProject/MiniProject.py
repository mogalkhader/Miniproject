import psycopg2
from sqlalchemy import create_engine
import pandas as pd
from datetime import datetime
import sql

# Creating connection to the Postgres database 

connect = psycopg2.connect(database="postgres", user="postgres", password="Mogal@5807", host="localhost", port=5432)
cursor = connect.cursor()

# Create framework that holds data

cust_df = pd.read_sql_query('SELECT * FROM Customers', connect)
trans_df = pd.read_sql_query('SELECT * FROM Transactions', connect)
account_info_df = pd.read_sql_query('SELECT * FROM account_info', connect)

# Extract/Filter customer data with account balances over $10,000.

filter_customers_df = account_info_df.loc[account_info_df.account_balance>10000]
#print(filter_customers_df)

# Joining filtered customer data with Transactions table using merge

custmr_trans_history_df = pd.merge(filter_customers_df, trans_df, how='inner', on='customer_id')
print(custmr_trans_history_df)

#Aggregate the total amount of deposits and withdrawals for each customer.

Total_Amnt = custmr_trans_history_df.groupby(['customer_id','transaction_type','transaction_date'])\
.agg(Total_Amount=pd.NamedAgg(column='amount', aggfunc='sum'))
Avg_Account_Bal=pd.merge(Total_Amnt,filter_customers_df,how='inner',on='customer_id')
print(Total_Amnt)

# Merge total Amount cost and Avg_Account_Balance

Custmer_Transaction_summary_df = pd.merge(Total_Amnt, Avg_Account_Bal, how='left', on='customer_id')

# Save transformed data into new table in the DB

table_name = 'Customer_Transactions_Summary'
Custmer_Transaction_summary_df.to_sql(table_name,cursor,if_exists='replace',index=False)
sql.write_frame(Custmer_Transaction_summary_df, 'Customer_Transactions_Summary', connect, flavor='postgresql')

# Save the aggregated data as a CSV file

Custmer_Transaction_summary_df.to_csv('Custmer_Transaction_Summary.csv', index=False)

# Statistical Insights
 # Generate basic statistics such as the average account balance

average_account_balance = custmr_trans_history_df.groupby(['customer_id'])\
.agg(Average_Account_Balance=pd.NamedAgg(column='account_balance', aggfunc='mean'))
print(average_account_balance)

# Total Transactions Per Customer

Total_Trans_Per_Customer = custmr_trans_history_df.groupby(['customer_id'])\
.agg(Total_Trans_Per_Customer=pd.NamedAgg(column='transaction_date', aggfunc='count'))
print(Total_Trans_Per_Customer)

# Distribution of Transaction Types.

Distrbution_Of_Trans = custmr_trans_history_df.groupby(['transaction_type'])\
.agg(Count_Of_Transactions=pd.NamedAgg(column='transaction_type', aggfunc='count'))

print(Distrbution_Of_Trans)

#saving statistical files into csv

average_account_balance.to_csv('Average_Account_Balance.csv', index=True)
Total_Trans_Per_Customer.to_csv('Total_Number_Of_Transactions.csv',index=True)
Distrbution_Of_Trans.to_csv('Distribution_Of_Transactions.csv',index=True)
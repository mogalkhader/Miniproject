-- Create Customers Table in postgres with the below attributes;
--•	Customers: Customer ID, Name, Age, Gender, Address, Account Type.

CREATE TABLE Customers (
  Customer_Id VARCHAR(20) PRIMARY KEY, 
  Customer_Name VARCHAR(30) NOT NULL, 
  Customer_Age INTEGER,
  Gender VARCHAR(10),
  Address VARCHAR(300) NOT NULL,
  Account_Type VARCHAR(12) NOT NULL
);

-- Create Transactions Table with below attributes;
--Transactions: Transaction ID, Customer ID (Foreign Key), Transaction Date, Amount, Transaction Type (Deposit/Withdrawal).

CREATE TABLE Transactions (
  Transaction_Id VARCHAR(20) NOT NULL, 
  Customer_Id VARCHAR(20) REFERENCES Customers (Customer_Id),
  Transaction_Date DATE NOT NULL,
  Amount INTEGER NOT NULL,
  Transaction_Type VARCHAR(10)
);

-- Create Account_Info Table with below attributes;
--Account_Info: Account ID, Customer ID (Foreign Key), Account Balance, Interest Rate, Account Status.

CREATE TABLE Account_Info (
  Account_Id VARCHAR(20) NOT NULL, 
  Customer_Id VARCHAR(20) REFERENCES Customers (Customer_Id),
  Account_Balance DECIMAL(10,5) NOT NULL,
   Interest_Rate DECIMAL(10,5),
  Account_Status VARCHAR(20)
);


COPY Customers FROM 'D:\MiniProject\Customers.csv' WITH DELIMITER ',' CSV HEADER;
COPY Transactions FROM 'D:\MiniProject\Transactions.csv' WITH DELIMITER ',' CSV HEADER;
COPY account_info FROM 'D:\MiniProject\account_info.csv' WITH DELIMITER ',' CSV HEADER;
